import { initializeApp } from "https://www.gstatic.com/firebasejs/12.1.0/firebase-app.js";
import { getFirestore, collection, getDocs, addDoc, serverTimestamp, query, orderBy } from "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js";
import { firebaseConfig } from "./firebase-config.js";

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

const grid = document.querySelector("#musicGrid");
const search = document.querySelector("#search");

let songs = [];

function escapeHtml(value="") {
  return String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
}

function render(list) {
  if (!list.length) {
    grid.innerHTML = '<p class="loading">No songs found yet.</p>';
    return;
  }
  grid.innerHTML = list.map(song => `
    <article class="card">
      <div class="cover">${escapeHtml((song.title || "♪").charAt(0).toUpperCase())}</div>
      <div class="card-body">
        <h3>${escapeHtml(song.title || "Untitled")}</h3>
        <div class="meta">${escapeHtml(song.artist || "ASTROBOY ZM")}</div>
        ${song.audioUrl ? `<audio class="audio" controls src="${escapeHtml(song.audioUrl)}"></audio>
        <div class="actions"><a class="button small" href="${escapeHtml(song.audioUrl)}" target="_blank" rel="noopener">Download / Open</a></div>` : '<p class="meta">Audio coming soon.</p>'}
      </div>
    </article>`).join("");
}

async function loadSongs() {
  try {
    const q = query(collection(db, "songs"), orderBy("createdAt", "desc"));
    const snap = await getDocs(q);
    songs = snap.docs.map(d => ({id:d.id, ...d.data()}));
    render(songs);
  } catch (e) {
    console.error(e);
    grid.innerHTML = '<p class="loading">Firebase is not connected yet. Add your Firebase web configuration, then publish again.</p>';
  }
}

search.addEventListener("input", () => {
  const term = search.value.toLowerCase().trim();
  render(songs.filter(s => `${s.title || ""} ${s.artist || ""}`.toLowerCase().includes(term)));
});

document.querySelector("#contactForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  const status = document.querySelector("#formStatus");
  status.textContent = "Sending...";
  try {
    await addDoc(collection(db, "messages"), {
      name: document.querySelector("#name").value.trim(),
      email: document.querySelector("#email").value.trim(),
      message: document.querySelector("#message").value.trim(),
      createdAt: serverTimestamp()
    });
    event.target.reset();
    status.textContent = "Message sent successfully.";
  } catch (e) {
    console.error(e);
    status.textContent = "Could not send. Check your Firebase setup.";
  }
});

document.querySelector("#year").textContent = new Date().getFullYear();
loadSongs();
