# Zednationmusic

Professional music website for ASTROBOY ZM.

## What is included
- Responsive professional homepage
- Music library loaded from Firebase Firestore
- Search
- Audio player and download/open button
- Contact form saved to Firestore
- Google-friendly title, description, keywords, robots.txt and sitemap
- Firebase Firestore and Storage security rules

## Important: Firebase connection
Open `firebase-config.js` and replace the placeholder values with your Firebase Web App configuration.

Firebase Console:
1. Open your project.
2. Project settings.
3. Under Your apps, create/select a Web app.
4. Copy the Firebase configuration.
5. Paste it into `firebase-config.js`.

## Adding songs
The public website reads songs from the Firestore collection `songs`.

Each song document can contain:
- title: string
- artist: string
- audioUrl: string
- createdAt: timestamp

For a real admin upload dashboard, the safest next step is to add Firebase Authentication and an admin-only upload page. Do not make public Storage writes available.

## Google Search
After publishing:
1. Open Google Search Console.
2. Add the GitHub Pages URL as a property.
3. Verify ownership using one of Google's offered methods.
4. Submit the sitemap.
5. Request indexing for the homepage.

Google indexing is not instant and Google decides when a page appears in search results.

## GitHub Pages
Upload the files to the root of your repository. Your main file must be named exactly `index.html`.
